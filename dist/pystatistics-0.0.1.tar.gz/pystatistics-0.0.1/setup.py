from setuptools import setup, find_packages

setup(
    name="pystatistics",
    version="0.0.1",
    author="Meteey (Mustafa Konur)",
    author_email="<konurmustafa17@gmail.com>",
    description="First publishing library try",
    packages=find_packages(),
    keywords=["statistics", "z-score", "normalization"]
)